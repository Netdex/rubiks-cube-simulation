#include "stdafx.h"
#include "rubiks_cube.h"
#include "triangle.h"

static glm::vec3 CUBIE_BASE_POINTS[] = {
	glm::vec3(-1, -1, 1), glm::vec3(-1, 1, 1), glm::vec3(1, -1, 1), glm::vec3(1, 1, 1),
	glm::vec3(-1, -1, -1), glm::vec3(-1, 1, -1), glm::vec3(1, -1, -1), glm::vec3(1, 1, -1),
};

static int CUBIE_FACE_VERTEX_INDEX[] = {
	2,1,0,	2,3,1,	// U
	7,1,3,	7,5,1,	// R
	6,3,2,	6,7,3,	// F
	5,7,6,	6,4,5,	// D
	2,0,4,	2,4,6,	// L
	0,1,5,	5,4,0   // B
};

rubiks_cube::rubiks_cube()
{
}


rubiks_cube::~rubiks_cube()
{
}

mesh rubiks_cube::build_cubie(glm::vec3 c[])
{
	std::vector<triangle> vertices;
	for(int f = 0; f < 6; f++)
	{
		for(int i = 0; i < 2; i++)
		{
			vertices.push_back(triangle(
				CUBIE_BASE_POINTS[CUBIE_FACE_VERTEX_INDEX[6 * f + 3 * i]],
				CUBIE_BASE_POINTS[CUBIE_FACE_VERTEX_INDEX[6 * f + 3 * i + 1]],
				CUBIE_BASE_POINTS[CUBIE_FACE_VERTEX_INDEX[6 * f + 3 * i + 2]],
				c[f]
			));
		}
	}
	mesh m;
	m.add(vertices);
	m.update();
	return m;
}
