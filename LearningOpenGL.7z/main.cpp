#include "stdafx.h"

#include "glsl_io.h"
#include "vertex.h"
#include "mesh.h"
#include "triangle.h"
#include "axis.h"
#include <glad/glad.h>
#include <glad/glad.h>
#include "light.h"
#include "shader.h"
#include "rubiks_cube.h"

/*
 * The magical journey of learning OpenGL
 */

#define SCREEN_WIDTH	1280.f
#define SCREEN_HEIGHT	720.f

bool wireframe = false;
bool focus = true;

GLFWwindow* window;
//shader shdr;
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (action == GLFW_PRESS) {
		switch (key)
		{
		case GLFW_KEY_E:
			wireframe = !wireframe;
			if (wireframe)	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			else			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			break;
		case GLFW_KEY_LEFT_ALT:
			focus = !focus;
			if (focus)		glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
			else			glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
			break;
		}
	}
}

int main(const int argc, const char *argv[])
{
	// initialize opengl through glfw
	if (!glfwInit())
	{
		printf("glfwInit() failed\n");
		return -1;
	}
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);

	window = glfwCreateWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "LearningOpenGL",
		nullptr /* set to glfwGetPrimaryMonitor() for fullscreen */, nullptr);
	glfwMakeContextCurrent(window);
	
	// load opengl functions
	if (!gladLoadGL())
	{
		printf("gladLoadGL() failed\n");
		return -1;
	}
	fprintf(stderr, "OpenGL %s\n", glGetString(GL_VERSION));

	// set general opengl settings
	glFrontFace(GL_CCW);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glEnable(GL_MULTISAMPLE);
	glEnable(GL_LINE_SMOOTH);

	// load shaders
	GLuint vertexShader = 0;
	if (!GLSL_LoadShader("vertex.g", GL_VERTEX_SHADER, vertexShader))
	{
		GLSL_PrintShaderLog(vertexShader);
		printf("failed to compile vertex shader\n");
		system("pause");
		return -1;
	}
	GLuint fragmentShader = 0;
	if (!GLSL_LoadShader("fragment.g", GL_FRAGMENT_SHADER, fragmentShader))
	{
		printf("failed to compile fragment shader\n");
		GLSL_PrintShaderLog(fragmentShader);
		system("pause");
		return -1;
	}
	// create shader program
	GLuint shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	glBindFragDataLocation(shaderProgram, 0, "render_color");
	glLinkProgram(shaderProgram);
	glUseProgram(shaderProgram);

	// get variables for MVP
	GLuint uniModel = glGetUniformLocation(shaderProgram, "model");
	GLuint uniView = glGetUniformLocation(shaderProgram, "view");
	float fov = glm::radians(45.0f);
	

	// static lighting
	light light(glm::vec3(0, 5, 0), glm::vec3(1, 1, 1));

	// initialize variables for camera
	GLuint uniCamera = glGetUniformLocation(shaderProgram, "camera_position");
	glm::vec3 position = glm::vec3(0, 0, 5);
	// horizontal angle : toward -Z
	float yaw = glm::pi<float>();
	// vertical angle : 0, look at the horizon
	float pitch = 0.0f;
	float speed = 3.0f;
	float mouseSpeed = 0.1f;
	glm::vec3 up(0, 1, 0);
	


//	// define verticies and elements of an object
//	std::vector<glm::vec3> vertices = {
//		glm::vec3(-0.75f,	1.0f,		0.125f),
//		glm::vec3(-0.5f,	1.0f,		0.125f),
//		glm::vec3(-0.75f,	-0.75f,		0.125f),
//		glm::vec3(-0.5f,	-0.75f,		0.125f),
//		glm::vec3(-0.75f,	-1.0f,		0.125f),
//		glm::vec3(0.25f,	-1.0f,		0.125f),
//		glm::vec3(0.25f,	-0.75f,		0.125f),
//		glm::vec3(-0.75f,	1.0f,		-0.125f),
//		glm::vec3(-0.5f,	1.0f,		-0.125f),
//		glm::vec3(-0.75f,	-0.75f,		-0.125f),
//		glm::vec3(-0.5f,	-0.75f,		-0.125f),
//		glm::vec3(-0.75f,	-1.0f,		-0.125f),
//		glm::vec3(0.25f,	-1.0f,		-0.125f),
//		glm::vec3(0.25f,	-0.75f,		-0.125f),
//	};
//
//	std::vector<GLuint> elements = {
//		3,1,0,		0,2,3,		6,2,4,		5,6,4,		7,8,10,		10,9,7,		11,9,13,	11,13,12,
//		8,7,0,		0,1,8,		0,7,9,		9,2,0,		8,1,3,		10,8,3,		9,11,4,		2,9,4,
//		13,10,3,	3,6,13,		13,6,5,		5,12,13,	4,11,12,	12,5,4
//	};
//
//	mesh cancer(false);
//
//	std::vector<triangle> triangles;
//	for (int i = 0; i < elements.size() / 3; i++)
//	{
//		triangles.push_back(triangle(
//			vertices[elements[i * 3]], vertices[elements[i * 3 + 1]], vertices[elements[i * 3 + 2]],
//			glm::vec3(1.0f, 1.0f, 1.0f)));
//	}
//
//	cancer.add(triangles);
//	cancer.update();
	
	axis axis(glm::vec3(0, 0, 0), glm::vec3(1, 0, 0), glm::vec3(0, 1, 0), glm::vec3(0, 0, 1));
	glm::vec3 colors[] = {
		glm::vec3(1,1,1), glm::vec3(0,1,0), glm::vec3(1,0,0),
		glm::vec3(0.7, 0.7, 0), glm::vec3(0,0,1), glm::vec3(0.7, 0.5, 0)
	};
	mesh cm = rubiks_cube::build_cubie(colors);

	// last-minute display settings
	glfwSwapInterval(1);
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
	glfwSetKeyCallback(window, key_callback);
	
	float lastTick = glfwGetTime();
	while (!glfwWindowShouldClose(window))
	{
		float now = glfwGetTime();
		float deltaTime = now - lastTick;
		lastTick = now;
		printf("\r%f ms/frame                        ", 1000.0f * deltaTime);
		// parse input
		if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
			glfwSetWindowShouldClose(window, GL_TRUE);

		// calculate mouse movement
		if (focus) {
			double xpos, ypos;
			glfwGetCursorPos(window, &xpos, &ypos);
			glfwSetCursorPos(window, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2);
			yaw += mouseSpeed * deltaTime * float(SCREEN_WIDTH / 2 - xpos);
			pitch += mouseSpeed * deltaTime * float(SCREEN_HEIGHT / 2 - ypos);
			if (pitch > glm::pi<float>() / 2 - 0.01)
				pitch = glm::pi<float>() / 2 - 0.01;
			if (pitch < -glm::pi<float>() / 2 + 0.01)
				pitch = -glm::pi<float>() / 2 + 0.01;
		}
		// calculate camera vectors
		glm::vec3 direction = normalize(glm::vec3(
			cos(pitch) * sin(yaw),
			sin(pitch),
			cos(pitch) * cos(yaw)
		));
		//printf("\r%f %f %f", position.x, position.y, position.z);
		glm::vec3 right = normalize(cross(direction, up));

		if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
			position += direction * deltaTime * speed;
		}
		if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
			position -= direction * deltaTime * speed;
		}
		if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
			position += right * deltaTime * speed;
		}
		if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
			position -= right * deltaTime * speed;
		}
		if (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS) {
			position -= glm::vec3(0, 1, 0) * deltaTime * speed;
		}
		if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) {
			position += glm::vec3(0, 1, 0) * deltaTime * speed;
		}
		if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS) {
			if(fov > 0.01)
				fov -= 0.01;
		}
		if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS) {
			if(fov < glm::pi<float>() - 0.01)
			fov += 0.01;
		}
		glUniform3fv(uniCamera, 1, value_ptr(position));

		glm::mat4 view = lookAt(
			position,
			position + direction,
			up
		);
		glUniformMatrix4fv(uniView, 1, GL_FALSE, value_ptr(view));

		glm::mat4 proj = glm::perspective(fov, SCREEN_WIDTH / SCREEN_HEIGHT, 0.01f, 100.0f);
		GLuint uniProj = glGetUniformLocation(shaderProgram, "proj");
		glUniformMatrix4fv(uniProj, 1, GL_FALSE, glm::value_ptr(proj));

		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		
		
		//light.color = glm::vec3(sin(now)* sin(now), cos(now) * cos(now), sin(now) * cos(now));
		const int count = 100;
		const int dist = 10;
		for (int i = 0; i < count; i++)
		{
			float offang = 2 * glm::pi<float>() / count * i;
//			light.color = glm::vec3(sin(now * 10 * offang)* sin(now * 10 * offang), cos(now * 10 * offang) * cos(now * 10 * offang), sin(now * 10 * offang + 1) * cos(now * offang + 1));
//			cancer.transform = translate(glm::mat4(), glm::vec3(dist * sin(0.5f * now * offang), dist * sin(0.1f * now * offang + glm::pi<float>()/2), dist * cos(0.5f * now * offang)));
//			cancer.transform = rotate(cancer.transform, 2.f * now * offang, glm::vec3(sin(now), sin(now), cos(now)));
//			cancer.draw(shaderProgram);

		}
		
		light.draw(shaderProgram);
		axis.draw(shaderProgram);
		cm.draw(shaderProgram);

		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glDeleteProgram(shaderProgram);
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	glfwTerminate();

	return 0;
}