#pragma once
#include "mesh.h"

class rubiks_cube
{
	mesh *cubies = nullptr;
public:
	rubiks_cube();
	~rubiks_cube();
	static mesh build_cubie(glm::vec3 colors[]);
private:
	/*
	 * Colors of cube in order URFDLB
	 */
	
};

